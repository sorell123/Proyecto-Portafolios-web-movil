import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { tap } from 'rxjs/operators';



import { Task } from './../interface/task'
import { Task2} from './../interface/task2'
import { Task3} from './../interface/task3'
import { Task4} from './../interface/task4'

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  
  //private api="http://localhost:3001/usuarios";
  //private api2="http://localhost:3001/asesoria";

  private api="http://localhost:8080/ApiRESTJAVA5/webresources/entity.usuarios";
  private api2="http://localhost:8080/ApiRESTJAVA5/webresources/entity.asesoria";

  private api3="http://localhost:8080/ApiRESTJAVA5/webresources/entity.reporteasesoria";
  private api4="http://localhost:8080/ApiRESTJAVA5/webresources/entity.mejora";
 

  constructor(public http: HttpClient,private storage: NativeStorage,
    ) { }

     //obtener task de Usuarios
   getAllTasks(){
      const path = `${this.api}/`;
      return this.http.get<Task[]>(path);
   }
 

   //obtener task de asesorias

   getAllTasks2(){
    const path = `${this.api2}/`;
    return this.http.get<Task2[]>(path);
 }

 //obtener task de mejora
 getAllTasks4(){
  const path = `${this.api4}/`;
  return this.http.get<Task2[]>(path);
}





   getTask(id: number) {
    const path = `${this.api}/${id}`;
    return this.http.get<Task>(path);
  }

  
  //usuarios
  createTask(task: Task) {
    const path = `${this.api}/`;
    return this.http.post<Task>(path, task);
  }


    //asesoria
    createTask2(task2: Task2) {
      const path = `${this.api2}/`;
      return this.http.post<Task2>(path, task2);
    }


    //Reporte
    createTask3(task3: Task3) {
      const path = `${this.api3}/`;
      return this.http.post<Task3>(path, task3);
    }

   //Mejora
   createTask4(task4: Task4) {
    const path = `${this.api4}/`;
    return this.http.post<Task4>(path, task4);
  }


  updateTask(task: Task) {
    const path = `${this.api}/${task.id}`;
    return this.http.put<Task>(path, task);
  }
 
  deleteTask(id: string) {
    const path = `${this.api}/${id}`;
    return this.http.delete(path);
  }

  
  deleteTask2(id: string) {
    const path = `${this.api2}/${id}`;
    return this.http.delete(path);
  }





}
