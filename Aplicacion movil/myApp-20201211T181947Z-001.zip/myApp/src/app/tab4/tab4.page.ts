import { Component, OnInit } from '@angular/core';

import { TaskService } from '../service/task.service'
import { Task } from '../interface/task';

import { AlertController, ToastController, LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page implements OnInit {

  tasks: Task[] = [];
  


  constructor(private taskService: TaskService,private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController) { }

    async ngOnInit() {
      const loading = await this.loadingCtrl.create({
        message: 'Cargando..',
      });
      await loading.present();
      this.taskService.getAllTasks()
      .subscribe(async (tasks) => {
        console.log(tasks);
        this.tasks = tasks;
        await loading.dismiss();
      });
    }

    createTask(
      apellidoMaterno: string,
      apellidoPaterno: string,
      id:number,
      nombre: string,
      password : string,
      tipoUsuario : string,
      username : string
      ){
      const task = {
        apellidoMaterno,
        apellidoPaterno,
        id,
        nombre,
        password,
        tipoUsuario,
        username,
        
  
      };
      this.taskService.createTask(task)
      .subscribe((newTask) => {
        this.tasks.unshift(newTask);
        this.presentToast('Usuario creado  correctamente');
      });
    }
  
  
    async openAlert() {
      const alert = await this.alertCtrl.create({
        header: 'Nueva Cuenta',
        
        inputs: [
          {
            
            name: 'apellidoMaterno',
             placeholder: 'Apellido Materno'
            
          },
          {
            name: 'apellidoPaterno',
             placeholder: 'apellido Paterno'
            
          },
          {
            name: 'id',
             placeholder: 'ID'
            
          },
          {
            name: 'nombre',
             placeholder: 'Nombre'
            
          },
          {
            name: 'password',
             placeholder: 'password',
             type:'password'
            
          },
          {
            name: 'tipoUsuario',
             placeholder: 'tipo usuario'
            
          },
          {
            name: 'username',
             placeholder: 'usuario'
            
          },
  
        ],
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            cssClass: 'secondary',
            handler: () => {
              console.log('Confirm Cancel');
            }
          }, {
            text: 'Crear',
            handler: (data) => {
              this.createTask(data.apellidoMaterno,data.apellidoPaterno,data.id,data.nombre,data.password,data.tipoUsuario,
                data.username);
  
  
            }
          }
        ]
      });
      await alert.present();
    }

  
  async presentToast(message: string) {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000
    });
    await toast.present();
  }
 
  async presentLoading() {
    const loading = await this.loadingCtrl.create({
      message: 'Cargando..',
      duration: 2000
    });
    await loading.present();
    return loading;
  }

  
  deleteTask(id: string, index: number){
    this.taskService.deleteTask(id)
    .subscribe(() => {
      this.tasks.splice(index, 6);
      this.presentToast('usuario eliminado correctamente');
    });
  }


}
