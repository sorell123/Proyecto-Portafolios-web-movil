import { Component, OnInit } from '@angular/core';

import { TaskService } from '../service/task.service'
import { Task4 } from '../interface/task4';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-tab5',
  templateUrl: './tab5.page.html',
  styleUrls: ['./tab5.page.scss'],
})
export class Tab5Page implements OnInit {

  tasks: Task4[] = [];

  constructor(private taskService: TaskService,private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController) { }

  async ngOnInit() {
    const loading = await this.loadingCtrl.create({
      message: 'Cargando..',
    });
    await loading.present();
    this.taskService.getAllTasks4()
    .subscribe(async (tasks) => {
      console.log(tasks);
      this.tasks = tasks;
      await loading.dismiss();
    });
  }


  createTask4(
    descripcion: string,
    fecha : string,
    id : number,
   
    ){
    const task2 = {
      descripcion,
      fecha,
      id,
    
 
      
    };
    this.taskService.createTask4(task2)
    .subscribe((newTask) => {
      this.tasks.unshift(newTask);
      this.presentToast('Mejora Ingresada');
    });
  }


  async openAlert() {
    const alert = await this.alertCtrl.create({
      header: 'Ingresar Mejora',
      
      inputs: [
        {
          
          name: 'descripcion',
           placeholder: 'Descripcion de Mejora'
          
        },
        {
          name: 'fecha',
           placeholder: 'aa/mm/yyyyha'
          
        },
        {
          name: 'id',
           placeholder: 'ID'
          
        },
    

      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Crear',
          handler: (data) => {
            this.createTask4(data.descripcion,data.fecha,data.id);


          }
        }
      ]
    });
    await alert.present();
  }


  async presentToast(message: string) {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000
    });
    await toast.present();
  }
 
  async presentLoading() {
    const loading = await this.loadingCtrl.create({
      message: 'Cargando..',
      duration: 2000
    });
    await loading.present();
    return loading;
  }

}
