import { Component } from '@angular/core';

import { PDFGenerator } from '@ionic-native/pdf-generator';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;



@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  pdfObject: any;

  constructor() {}

  generarPDF()
  { 
    alert('PDF Generado');

    let docDefinition= {
      content: [
        
        {text: '', style: 'header'},
        'Documentación oficial de la compañía No más  accidentes ',
        '  ',
        {text: 'Reporte control de pagos de clientes', style: 'subheader', alignment:'center' },
        '     ',
        {
          style: 'tableExample',
          table: {
            body: [
              ['Nombre', 'Apellido Paterno', 'Apellido Materno','Usuario','Deudor'],
              ['Roberto', 'Martinez', 'Cordoba','robert','Deudor'],
              ['Axa', 'Cortez', 'Letelier','axa','Cancelado'],
              ['Jose Luis', 'Henrique', 'Catalan','jose','Deudor'],
              ['Maria', 'Luisa', 'Fernandez','maria','Cancelado'],
              ['Raul', 'Gonzalez', 'Perez','raul','Deudor'],
              ['Marcelo', 'Palacio', 'Salazar','marcelo','Cancelado'],
              ['Rodrigo', 'Maldi', 'ToTo','rodrigo','Deudor']
            ]
          }
        },
        '     ',
        {text: 'Reporte de Asesorias', style: 'subheader', alignment:'center' },
        '     ',

        {
          style: 'tableExample',
          table: {
            body: [
              ['Descripcion', 'Tipo', 'Empleado a Cargo','Estado'],
              ['A.Minera', 'Normal', 'Sergio Orell','En proceso'],
              ['A.Industrial', 'Normal', 'Sergio Orell','Finalizada'],
              ['A.Construccion', 'Especial', 'Sergio Orell','En proceso'],
              ['A.Minera', 'Especial', 'Sergio Orell','En proceso'],
              ['A.Industrial', 'Normal', 'Sergio Orell','En proceso'],
              ['A.Minera', 'Especial', 'Sergio Orell','Finalizada'],
              ['A.Construccion', 'Normal', 'Sergio Orell','En proceso'],
          
            ]
          }
        },
        '     ',
        {text: 'Reportes Actividades de mejora', style: 'subheader', alignment:'center' },
        '     ',

        {
          style: 'tableExample',
          table: {
            body: [
              ['Actividad', 'descripcion', 'estado',],
              ['A.Minera', 'Se recomienda cambiar cables dañados', 'en proceso',],
              ['A.Industrial', 'Eliminar las vibraciones en la fuente de la misma', 'Finalizado',],
              ['A.Construccion', 'Revisar calderas', 'en proceso',],
              ['A.Minera', 'Cambiar techos , cambiar equipos de seguridad', 'en proceso',],
              ['A.Construccion', 'Seguir normas', 'en proceso',],
           
          
            ]
          }
        },

        {text: 'Reportes accidentabilidad', style: 'subheader', alignment:'center' },
        '     ',
        {
          style: 'tableExample',
          table: {
            body: [
              ['Industria', 'Cant de accidentes', 'Solucionados','En proceso'],
              ['Mineria', '50', '40','10'],
              ['Construccion', '15', '10','5'],
              ['Industrial', '25', '20','5'],
           
          
            ]
          }
        },

        
      ]
    
    };
      this.pdfObject = pdfMake.createPdf(docDefinition);
      this.pdfObject.download();

  }


  generarPDF2()
  { 
    alert('PDF Generado');

    let docDefinition= {
      content: [
        
        {text: '', style: 'header'},
        'Documentación oficial de la compañía No más  accidentes ',
        '  ',
       
        {text: 'Reporte de Clientes', style: 'subheader', alignment:'center' },
        '     ',

        {
          style: 'tableExample',
          table: {
            body: [
              ['Nombre', 'Apellido Paterno', 'Apellido Materno','Asesorias normales','Asesorias especiales','Proceso','Pago'],
              ['Roberto ', 'Martinez', 'Pacheco','2','1','en proceso','Pendiente'],
              ['Axa ', 'Cortez', 'Letelier','5','2','Finalizado','Cancelado'],
              ['Rodrigo ', 'Sistema', 'Fernandez','23','1','en proceso','Pendiente'],
              ['Marcos ', 'Rojo', 'Fernandez','4','0','Finalizado','Deudor'],
              ['Henrique ', 'Perez', 'Perez','0','1','Finalizado','cancelado'],
              ['Felipe ', 'Iturra', 'Diamond','2','1','en proceso','Deudor'],
              ['Gabriel ', 'Espejo', 'Droguett','0','5','Finalizado','cancelado'],
              ['Matias ', 'Rodriguez', 'Alcazar','10','1','en proceso','Deudor'],
              ['Jaime ', 'Ronaldo', 'zidane','5','0','en proceso','cancelado'],
              ['Alvaro ', 'Lopez', 'Martines','4','1','en proceso','Deudor'],
              ['Patricio ', 'Gonzalez', 'Gonzalez','1','0','Finalizado','Deudor'],
              ['Maria ', 'Hex', 'Geeel','0','1','en proceso','cancelado'],
         
        
          
            ]
          }
        },

      ]
    
    };
      this.pdfObject = pdfMake.createPdf(docDefinition);
      this.pdfObject.download();

  }

  styles: {
    header: {
      fontSize: 18,
      bold: true,
      alignment: 'right',
      margin: [0, 190, 0, 80]
    },
    subheader: {
      fontSize: 14
    },
    superMargin: {
      margin: [20, 0, 40, 0],
      fontSize: 15
    }
  }
}
