import { Component, OnInit} from '@angular/core';

import { AlertController, ToastController, LoadingController } from '@ionic/angular';


import { AuthConstants } from './../config/auth-constants';
import { AuthService } from '../service/auth.service';
import { StorageService } from '../service/storage.service';




@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  postData = {
    username: '',
    password: ''
};





  constructor(
    private authService: AuthService,
    private storageService: StorageService,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController
   ) { }

  ngOnInit() {
  }


  validateInputs() {
    let username = this.postData.username.trim();
    let password = this.postData.password.trim();
    return (
    this.postData.username &&
    this.postData.password &&
    username.length > 0 &&
    password.length > 0
    );
    }


  

    async presentToast(message: string) {
      const toast = await this.toastCtrl.create({
        message,
        duration: 3000
      });
      await toast.present();
    }

    login1(){
    
        this.presentToast('Bienvenido profesional ');
      };
    




   // loginAction() {
    //  if (this.validateInputs()) {
     // this.authService.login(this.postData).subscribe(
     // (res: any) => {
      //if (res.userData) {
      // Storing the User data.
     // this.storageService.store(AuthConstants.AUTH, res.userData);
    
   //   } else {
     // console.log('incorrect username or password.');
     // }
      //},
     // (error: any) => {
     // console.log('Network Issue.');
     // }
     
     //);
      //} else {
      //console.log('Please enter email/username or password.');
     // }
     // }
}




