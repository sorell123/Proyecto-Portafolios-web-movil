import { Component } from '@angular/core';


import { TaskService } from '../service/task.service'
import { Task2 } from '../interface/task2';
import { Task3 } from '../interface/task3';

import { AlertController, ToastController, LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  tasks: Task2[] = [];

  tasks3: Task3[] = [];

  constructor(private taskService: TaskService,private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController) {}


    createTask2(
      descripcion: string,
      descripcion2 : string,
      empleado : string,
      fecha : string,
      id : number,
      tipoAsesoria : string

     
     
      ){
      const task2 = {
        descripcion,
        descripcion2,
        empleado,
        fecha,
        id,
        tipoAsesoria

      
   
        
      };
      this.taskService.createTask2(task2)
      .subscribe((newTask) => {
        this.tasks.unshift(newTask);
        this.presentToast('Solicitud Enviada');
      });
    }
  

    logout(){
    
      this.presentToast('sesion finalizada');
    };
  
    async openAlert() {
      const alert = await this.alertCtrl.create({
        header: 'Solicitar asesoria especial',
        
        inputs: [
          {
            
            name: 'descripcion',
             placeholder: 'Mineria/Industrial/Construccion'
            
          },
          {
            name: 'descripcion2',
             placeholder: 'Descripcion de asesoria'
            
          },
          {
            name: 'empleado',
             placeholder: 'Empleado a cargo'
            
          },
          {
            name: 'fecha',
             placeholder: 'aa/mm/yyy'
            
          },
      
          {
            name: 'tipoAsesoria',
             placeholder: 'Tipo de Asesoria'
            
          },
      
  
        ],
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            cssClass: 'secondary',
            handler: () => {
              console.log('Confirm Cancel');
            }
          }, {
            text: 'Crear',
            handler: (data) => {
              this.createTask2(data.descripcion,data.descripcion2,data.empleado,data.fecha,data.id,data.tipoAsesoria);
  
  
            }
          }
        ]
      });
      await alert.present();
    }
  
  
    async presentToast(message: string) {
      const toast = await this.toastCtrl.create({
        message,
        duration: 3000
      });
      await toast.present();
    }
   
    async presentLoading() {
      const loading = await this.loadingCtrl.create({
        message: 'Cargando..',
        duration: 2000
      });
      await loading.present();
      return loading;
    }


    createTask3(
      cliente: string,
      descripcion : string,
      empresa : string,
      fecha : string,
      idReporte : number,
      
      ){
      const task2 = {

        cliente,
        descripcion,
        empresa,
        fecha,
        idReporte,
        
      };
      this.taskService.createTask3(task2)
      .subscribe((newTask) => {
        this.tasks3.unshift(newTask);
        this.presentToast('Reporte Enviado');
      });
    }
  
  
    async openAlert2() {
      const alert = await this.alertCtrl.create({
        header: 'Reportar Accidente',
        
        inputs: [
          {
            
            name: 'cliente',
             placeholder: 'Nombre cliente'
            
          },
          {
            name: 'descripcion',
             placeholder: 'Descripcion de Accidente'
            
          },
          {
            name: 'empresa',
             placeholder: 'Nombre empresa'
            
          },
          {
            name: 'fecha',
             placeholder: 'aa/mm/yyy'
            
          },
          {
            name: 'idReporte',
             placeholder: 'ID'
            
          },
       
  
        ],
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            cssClass: 'secondary',
            handler: () => {
              console.log('Confirm Cancel');
            }
          }, {
            text: 'Crear',
            handler: (data) => {
              this.createTask3(data.cliente,data.descripcion,data.empresa,data.fecha,data.idReporte);
  
  
            }
          }
        ]
      });
      await alert.present();
    }

}
