export interface Task3 {


    id_reporte?: number;
    empresa: string;
    cliente: string;
    fecha: string;
    descripcion: string;

}
