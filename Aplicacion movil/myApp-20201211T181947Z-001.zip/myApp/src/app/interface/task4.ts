export interface Task4 {


    id?: number;
    fecha: string;
    descripcion: string;
   

}
