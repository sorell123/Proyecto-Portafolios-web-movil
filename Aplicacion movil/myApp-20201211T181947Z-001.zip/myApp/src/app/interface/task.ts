export interface Task {
    id?: number;
    nombre: string;
    apellidoPaterno: string;
    apellidoMaterno: string;
    username : string;
    password : string;
    tipoUsuario : string;

    

}
