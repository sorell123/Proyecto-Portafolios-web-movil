export interface Task2 {
    
    id?: number;
    descripcion: string;
    tipoAsesoria: string;
    descripcion2: string;
    fecha: string;
    empleado: string;
}
