import { Component } from '@angular/core';


import { TaskService } from '../service/task.service'
import { Task2 } from '../interface/task2';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  
  tasks: Task2[] = [];

  constructor(private taskService: TaskService,private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController) {}


    async ngOnInit() {
      const loading = await this.loadingCtrl.create({
        message: 'Cargando..',
      });
      await loading.present();
      this.taskService.getAllTasks2()
      .subscribe(async (tasks) => {
        console.log(tasks);
        this.tasks = tasks;
        await loading.dismiss();
      });
    }


    async presentToast(message: string) {
      const toast = await this.toastCtrl.create({
        message,
        duration: 3000
      });
      await toast.present();
    }
   
    async presentLoading() {
      const loading = await this.loadingCtrl.create({
        message: 'Cargando..',
        duration: 2000
      });
      await loading.present();
      return loading;
    }

    deleteTask2(id: string, index: number){
      this.taskService.deleteTask2(id)
      .subscribe(() => {
        this.tasks.splice(index, 6);
        this.presentToast('Asesoria Eliminada');
      });
    }



    

}
