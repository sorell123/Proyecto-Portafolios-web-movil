export const environment = {
  production: true,
  apiUrl: 'https://api.thewallscript.com/restful/'
};
